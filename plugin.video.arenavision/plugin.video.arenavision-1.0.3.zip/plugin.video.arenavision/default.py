import sys
import xbmcgui
import xbmcplugin

addon_handle = int(sys.argv[1])



xbmcplugin.setContent(addon_handle, 'movies')
url = 'https://ul.cdn946.net:8443/hls/h6kg44f76gaa.m3u8?s=0W-xgZ08CuaCJ8od3QQckA&e=1598377295'
li = xbmcgui.ListItem('Movistar LaLiga', iconImage='DefaultVideo.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://ul.cdn946.net:8443/hls/5jx78y3g2.m3u8?s=xlyT-JVpm6Yw9OgGeuXu-Q&e=1598377984'
li = xbmcgui.ListItem('Movistar LigadeCampeones', iconImage='DefaultVideo.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://adictosaldeporte.com/TV/deportes/deportes/'
li = xbmcgui.ListItem('Av1', iconImage='DefaultVideo.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'plugin://program.plexus/?mode=1&url=acestream://2aabe1d62c475873d6644fc9ff0397e53aa4356b&name=My+acestream+channel'
li = xbmcgui.ListItem('Av7', iconImage='DefaultVideo.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'plugin://program.plexus/?mode=1&url=acestream://349d10a91255b7ca495d595c31e7723006e5ebb1&name=My+acestream+channel'
li = xbmcgui.ListItem('Av9', iconImage='DefaultVideo.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'plugin://program.plexus/?mode=1&url=acestream://349d10a91255b7ca495d595c31e7723006e5ebb1&name=My+acestream+channel'
li = xbmcgui.ListItem('Movistar F1', iconImage='DefaultVideo.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'plugin://program.plexus/?mode=1&url=acestream://f98d848890d2d464b22c3f5d67c1b5603a5364f5&name=My+acestream+channel'
li = xbmcgui.ListItem('#Vamos', iconImage='DefaultVideo.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://ul.cdn946.net:8443/hls/63nzivsd5c9.m3u8?s=cQaNB1VIyhU1eipAqiSaWQ&e=1598378242'
li = xbmcgui.ListItem('Movistar Deportes', iconImage='DefaultVideo.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://127.0.0.1:6878/ace/manifest.m3u8?url=https://sh.dailysportlist.xyz/1a/1.m3u8'
li = xbmcgui.ListItem('Daily CH1', iconImage='DefaultVideo.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://127.0.0.1:6878/ace/manifest.m3u8?url=https://xxx.dailysportlist.xyz/4/4.m3u8'
li = xbmcgui.ListItem('Daily CH3', iconImage='DefaultVideo.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)


xbmcplugin.endOfDirectory(addon_handle)
